[
    {
        "name": "Premium Black Hoodie",
        "price": 39.99,
        "description": "This premium black hoodie is crafted from high-quality cotton for maximum comfort and durability. Featuring a sleek modern fit, it's perfect for everyday wear.",
        "stock": 50,
        "image": "product1.jpg"
    },
    {
        "name": "Stylish Blue Jeans",
        "price": 49.99,
        "description": "These stylish blue jeans are perfect for any casual occasion. Made with high-quality denim, they offer a comfortable and sleek fit.",
        "stock": 100,
        "image": "path_or_url_to_image2.jpg"
    },
    {
        "name": "Classic White Sneakers",
        "price": 59.99,
        "description": "These classic white sneakers combine comfort and style, designed for everyday wear. The perfect addition to any wardrobe.",
        "stock": 150,
        "image": "path_or_url_to_image3.jpg"
    }
]
